﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using Tobii.Interaction;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Automation;
using System.Threading;
using System.Windows.Media;


namespace eye_tracking_zoom
{

    class Program
    {
        [DllImport("user32.dll", EntryPoint = "SetWindowPos")]
        private static extern bool SetWindowPos(IntPtr hWnd,
               int hWndInsertAfter, int x, int y, int cx, int cy, int uFlags);

        static void Main(string[] args)
        {
            MagnifyBox magnifyBox = new MagnifyBox();
            Application.EnableVisualStyles();
            Application.Run(magnifyBox);
        }

        public class MagnifyBox : Form
        {
            [DllImport("User32.dll")]
            public static extern IntPtr GetDC(IntPtr hwnd);

            [DllImport("User32.dll")]
            public static extern void ReleaseDC(IntPtr hwnd, IntPtr dc);

            private PictureBox pictureBox;
            private System.Windows.Forms.Timer timer;
            private Bitmap bitmap, dond;
            private Graphics graphics;

            public MagnifyBox()
            {
                AllowTransparency = false;
                //TransparencyKey = System.Drawing.Color.Turquoise;
                //BackColor = System.Drawing.Color.Turquoise;
                FormBorderStyle = FormBorderStyle.None;
                ShowInTaskbar = false;
                TopMost = true;
                ClientSize = new System.Drawing.Size(300, 300);
                StartPosition = FormStartPosition.CenterScreen;
                bitmap = new Bitmap(150, 150);
                dond = new Bitmap(300, 300);

                pictureBox = new PictureBox();
                pictureBox.Width = 300;
                pictureBox.Height = 300;
                //pictureBox.BorderStyle = BorderStyle.FixedSingle;
                pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                Controls.Add(pictureBox);

                graphics = Graphics.FromImage(dond);

                timer = new System.Windows.Forms.Timer();
                timer.Interval = 100;
                timer.Tick += Timer_Tick;
                timer.Start();

                var host = new Host();
                var gazePointDataStream = host.Streams.CreateGazePointDataStream();
                gazePointDataStream.GazePoint(MovePosition);
            }

            public void MovePosition(double gazePointX, double gazePointY, double tmp)
            {
                //Top = Convert.ToInt32(gazePointY) - 150;
                //Left = Convert.ToInt32(gazePointX) - 150;
            }

            private void Timer_Tick(object sender, EventArgs e)
            {
                using (Graphics gr = Graphics.FromImage(bitmap))
                {
                    gr.CopyFromScreen(Cursor.Position.X - 75, Cursor.Position.Y - 75, 0, 0, bitmap.Size);
                }

                //IntPtr desktopDC = GetDC(IntPtr.Zero); // Get the full screen DC

                //Graphics g = Graphics.FromHdc(desktopDC); // Get the full screen GFX device
                graphics.DrawImage(bitmap, Cursor.Position.X - 150, Cursor.Position.Y - 150, 300, 300); // Render the image
                //ReleaseDC(IntPtr.Zero, GetDC(IntPtr.Zero));
                pictureBox.Image = dond;
                //g.Dispose();

                //graphics.CopyFromScreen(Left + 75, Top + 75, 0, 0, new System.Drawing.Size(150, 150));
                //graphics.DrawImage(bitmap, new Point(0, 0));
                //pictureBox.Image = bitmap;

            }
        }
    }
}
